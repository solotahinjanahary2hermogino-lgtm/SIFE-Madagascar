# Déploiement v16

## 1. Supabase
- Créer un projet
- SQL Editor > coller `supabase/schema.sql`
- Authentication > activer Email
- Storage > créer un bucket privé `sife-documents`

## 2. Netlify
- Déployer le dossier `web/`
- Ajouter les variables d'environnement si nécessaire
- Activer HTTPS automatique

## 3. Backend FastAPI
- `pip install -r backend/requirements.txt`
- `uvicorn main:app --reload`
- Déployer sur Render, Railway, Fly.io ou un VPS sécurisé

## 4. Paiements
- Choisir une passerelle Mobile Money officielle
- Créer des webhooks signés
- Ne jamais valider un paiement sur capture d'écran

## 5. Tests avant production
- Client A ne voit pas les dossiers de client B
- Un agent ne modifie pas les paiements
- Un document supprimé n'est plus accessible
- Une sauvegarde peut être restaurée
- Une mission IA ne dépasse pas ses permissions
