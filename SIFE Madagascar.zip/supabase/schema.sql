-- SIFE Madagascar v16 — Schéma PostgreSQL / Supabase
-- Exécuter dans SQL Editor Supabase.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  phone text,
  role text not null default 'client',
  created_at timestamptz default now()
);

create table if not exists public.organizations (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid references auth.users(id) on delete cascade,
  name text not null,
  type text,
  created_at timestamptz default now()
);

create table if not exists public.cases (
  id uuid primary key default gen_random_uuid(),
  reference text unique not null,
  client_id uuid references auth.users(id) on delete cascade,
  organization_id uuid references public.organizations(id),
  profile_type text,
  need text,
  description text,
  status text not null default 'recu',
  assigned_agent uuid references auth.users(id),
  internal_notes text,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists public.case_assignments (
  id uuid primary key default gen_random_uuid(),
  case_id uuid references public.cases(id) on delete cascade,
  agent_id uuid references auth.users(id) on delete cascade,
  assigned_at timestamptz default now()
);

create table if not exists public.documents (
  id uuid primary key default gen_random_uuid(),
  case_id uuid references public.cases(id) on delete cascade,
  owner_id uuid references auth.users(id) on delete cascade,
  storage_path text not null,
  file_name text not null,
  mime_type text,
  size_bytes bigint,
  status text default 'recu',
  created_at timestamptz default now()
);

create table if not exists public.invoices (
  id uuid primary key default gen_random_uuid(),
  reference text unique not null,
  client_id uuid references auth.users(id) on delete cascade,
  case_id uuid references public.cases(id),
  service_name text,
  amount numeric not null,
  currency text default 'MGA',
  status text default 'emise',
  created_at timestamptz default now()
);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  reference text unique not null,
  client_id uuid references auth.users(id) on delete cascade,
  invoice_id uuid references public.invoices(id),
  amount numeric not null,
  currency text default 'MGA',
  provider text,
  provider_transaction_id text,
  status text not null default 'created',
  reconciled_at timestamptz,
  created_at timestamptz default now()
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  case_id uuid references public.cases(id) on delete cascade,
  sender_id uuid references auth.users(id) on delete cascade,
  recipient_id uuid references auth.users(id),
  content text not null,
  created_at timestamptz default now()
);

create table if not exists public.ai_tasks (
  id uuid primary key default gen_random_uuid(),
  case_id uuid references public.cases(id) on delete cascade,
  agent text not null,
  instruction text not null,
  autonomy_level int not null default 0,
  result text,
  status text not null default 'a_valider',
  created_by uuid references auth.users(id),
  created_at timestamptz default now()
);

create table if not exists public.audit_logs (
  id bigint generated always as identity primary key,
  actor_id uuid references auth.users(id),
  action text not null,
  target_type text,
  target_id text,
  details jsonb,
  created_at timestamptz default now()
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  title text not null,
  body text,
  read boolean default false,
  created_at timestamptz default now()
);

-- RLS
alter table public.profiles enable row level security;
alter table public.organizations enable row level security;
alter table public.cases enable row level security;
alter table public.case_assignments enable row level security;
alter table public.documents enable row level security;
alter table public.invoices enable row level security;
alter table public.payments enable row level security;
alter table public.messages enable row level security;
alter table public.ai_tasks enable row level security;
alter table public.audit_logs enable row level security;
alter table public.notifications enable row level security;

create policy "profiles self" on public.profiles for select using (auth.uid() = id);
create policy "profiles self update" on public.profiles for update using (auth.uid() = id);

create policy "cases owner or staff" on public.cases for select using (
  auth.uid() = client_id
  or auth.uid() = assigned_agent
  or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role in ('superadministrateur','directeur','analyste_financier','enqueteur','comptable','commercial','responsable_conformite'))
);

create policy "client create own case" on public.cases for insert with check (auth.uid() = client_id);
create policy "staff update case" on public.cases for update using (
  auth.uid() = assigned_agent
  or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role in ('superadministrateur','directeur','responsable_conformite'))
);

create policy "documents owner or staff" on public.documents for select using (
  auth.uid() = owner_id
  or exists (select 1 from public.cases c join public.profiles p on p.id = auth.uid() where c.id = documents.case_id and (c.assigned_agent = auth.uid() or p.role in ('superadministrateur','directeur','analyste_financier','enqueteur','responsable_conformite')))
);

create policy "owner upload document" on public.documents for insert with check (auth.uid() = owner_id);

create policy "invoices owner or finance" on public.invoices for select using (
  auth.uid() = client_id
  or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role in ('superadministrateur','directeur','comptable'))
);

create policy "payments owner or finance" on public.payments for select using (
  auth.uid() = client_id
  or exists (select 1 from public.profiles p where p.id = auth.uid() and p.role in ('superadministrateur','directeur','comptable'))
);

create policy "messages participants" on public.messages for select using (
  auth.uid() = sender_id or auth.uid() = recipient_id
  or exists (select 1 from public.cases c join public.profiles p on p.id = auth.uid() where c.id = messages.case_id and (c.client_id = auth.uid() or c.assigned_agent = auth.uid() or p.role in ('superadministrateur','directeur')))
);

create policy "ai tasks staff" on public.ai_tasks for select using (
  exists (select 1 from public.profiles p where p.id = auth.uid() and p.role in ('superadministrateur','directeur','analyste_financier','enqueteur','responsable_conformite'))
);

create policy "audit logs staff read" on public.audit_logs for select using (
  exists (select 1 from public.profiles p where p.id = auth.uid() and p.role in ('superadministrateur','directeur','responsable_conformite'))
);

create policy "notifications own" on public.notifications for select using (auth.uid() = user_id);
