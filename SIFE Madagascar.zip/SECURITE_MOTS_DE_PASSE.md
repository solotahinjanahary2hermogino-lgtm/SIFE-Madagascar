# Sécurité des accès SIFE Madagascar

Les mots de passe des comptes Administrateur, Direction, Comptabilité et Enquêtes ne doivent jamais être écrits dans le code, dans un fichier ZIP public, dans GitHub ou dans le stockage du navigateur.

Chaque utilisateur doit avoir son propre compte Supabase Auth, avec :

- E-mail professionnel
- Mot de passe unique et robuste
- Rôle attribué côté serveur
- Double authentification activée si disponible
- Réinitialisation par e-mail
- Journalisation des connexions

Les rôles sont attribués depuis l'Espace Direction > Utilisateurs & rôles, après création des comptes dans Supabase.

Ne partagez jamais les mots de passe par WhatsApp, e-mail ou dans un message à une IA.
