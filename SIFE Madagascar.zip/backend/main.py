from fastapi import FastAPI, HTTPException, Depends
from pydantic import BaseModel, Field
from typing import Optional
import os

app = FastAPI(title="SIFE Madagascar API", version="16.0.0")

class CaseCreate(BaseModel):
    reference: str = Field(min_length=6, max_length=30)
    profile_type: str
    need: str
    description: str = Field(max_length=5000)

class PaymentCreate(BaseModel):
    reference: str
    amount: float = Field(gt=0)
    provider: str

class AITaskCreate(BaseModel):
    case_id: str
    agent: str
    instruction: str = Field(max_length=4000)
    autonomy_level: int = Field(ge=0, le=5)

@app.get("/health")
def health():
    return {"status": "ok", "service": "sife-madagascar-api", "version": "16.0.0"}

@app.post("/cases")
def create_case(payload: CaseCreate, user=Depends(lambda: None)):
    # TODO: vérifier le JWT Supabase et insérer dans PostgreSQL avec RLS
    raise HTTPException(status_code=501, detail="À connecter à Supabase / PostgreSQL")

@app.post("/payments")
def create_payment(payload: PaymentCreate, user=Depends(lambda: None)):
    # TODO: créer une commande auprès de la passerelle Mobile Money autorisée
    raise HTTPException(status_code=501, detail="Passerelle Mobile Money non configurée")

@app.post("/ai/tasks")
def create_ai_task(payload: AITaskCreate, user=Depends(lambda: None)):
    if payload.autonomy_level >= 4:
        raise HTTPException(status_code=403, detail="Autonomie étendue nécessite une configuration de sécurité dédiée")
    raise HTTPException(status_code=501, detail="Orchestrateur IA non connecté")
