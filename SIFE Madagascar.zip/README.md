# SIFE Madagascar v16.2 — Cabinet Freelance Professionnel

SIFE Madagascar est un cabinet freelance d’audit, sûreté, investigations, gestion des risques, recouvrement, accompagnement entrepreneurial et accès aux financements. La structure est appelée à évoluer vers une entreprise professionnelle complète.

**Slogan : Ce sont les petits détails qui font la différence.**

## Architecture

- Frontend : PWA responsive (web, Android, ordinateur)
- Authentification : Supabase Auth
- Base de données : PostgreSQL / Supabase
- Stockage documents : Supabase Storage privé
- Backend métier : FastAPI
- Agents IA : KINGA, TATA, SENTINELLE, Mpanadihady, Mpanamarina, Mpitantana, Mpandinika, Mpitati-baovao
- Paiements : passerelle Mobile Money à intégrer avec webhooks et rapprochement

## Sécurité

- Mots de passe gérés par Supabase Auth, jamais stockés en clair côté client
- Rôles vérifiés côté serveur
- RLS activée sur toutes les tables exposées
- Journal d'audit
- Validation des entrées avec Pydantic
- CSP, HTTPS et séparation des caches
- Les paiements ne sont pas validés automatiquement sans confirmation authentifiée

## Contact

- Téléphone / WhatsApp : 038 97 248 01
- E-mail : solotahinjanahary2hermogino@gmail.com

## Déploiement

1. Créer un projet Supabase.
2. Exécuter `supabase/schema.sql` dans SQL Editor.
3. Configurer les variables dans `.env`.
4. Déployer `web/` sur Netlify ou Vercel.
5. Déployer `backend/` avec FastAPI.
6. Tester l'authentification, les dossiers, les documents et les paiements.

## Limites actuelles

Cette version prépare l'architecture sécurisée, mais les intégrations réelles nécessitent :

- Un projet Supabase configuré
- Les clés API dans des variables d'environnement
- Une passerelle Mobile Money officielle
- Une connexion WhatsApp Business / e-mail
- Un orchestrateur IA et des workers
- Des tests de sécurité avant production
