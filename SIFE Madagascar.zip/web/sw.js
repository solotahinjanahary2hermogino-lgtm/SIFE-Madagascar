const STATIC_CACHE='sife-static-v16';
const ASSETS=['./','./index.html','./offline.html','./manifest.json'];
self.addEventListener('install',e=>{e.waitUntil(caches.open(STATIC_CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting()))});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==STATIC_CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()))});
self.addEventListener('fetch',e=>{
const url=new URL(e.request.url);
if(url.pathname.includes('/auth/')||url.pathname.includes('/payment')||url.pathname.includes('/rest/v1'))return;
if(e.request.mode==='navigate'){e.respondWith(fetch(e.request).catch(()=>caches.match('./offline.html')));return}
if(e.request.destination==='style'||e.request.destination==='script'||e.request.destination==='image'||e.request.destination==='manifest'){
e.respondWith(caches.open(STATIC_CACHE).then(c=>c.match(e.request).then(r=>r||fetch(e.request).then(res=>{c.put(e.request,res.clone());return res}))))}
});
